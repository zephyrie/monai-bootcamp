class _Transition(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm : __torch__.torch.nn.modules.batchnorm.___torch_mangle_122.BatchNorm2d
  relu : __torch__.torch.nn.modules.activation.ReLU
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_123.Conv2d
  pool : __torch__.torch.nn.modules.pooling.AvgPool2d
  def forward(self: __torch__.monai.networks.nets.densenet.___torch_mangle_124._Transition,
    input: Tensor) -> Tensor:
    _0 = self.norm
    _1 = self.relu
    _2 = self.conv
    _3 = self.pool
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    input2 = (_2).forward(input1, )
    return (_3).forward(input2, )
  def __len__(self: __torch__.monai.networks.nets.densenet.___torch_mangle_124._Transition) -> int:
    return 4
