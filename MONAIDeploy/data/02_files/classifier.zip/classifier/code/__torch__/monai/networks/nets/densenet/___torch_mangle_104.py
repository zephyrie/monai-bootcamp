class _DenseLayer(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  layers : __torch__.torch.nn.modules.container.___torch_mangle_103.Sequential
  def forward(self: __torch__.monai.networks.nets.densenet.___torch_mangle_104._DenseLayer,
    x: Tensor) -> Tensor:
    new_features = (self.layers).forward(x, )
    return torch.cat([x, new_features], 1)
