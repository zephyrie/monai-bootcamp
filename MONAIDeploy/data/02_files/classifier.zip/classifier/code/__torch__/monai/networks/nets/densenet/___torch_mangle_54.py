class _DenseBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  denselayer1 : __torch__.monai.networks.nets.densenet.___torch_mangle_9._DenseLayer
  denselayer2 : __torch__.monai.networks.nets.densenet.___torch_mangle_13._DenseLayer
  denselayer3 : __torch__.monai.networks.nets.densenet.___torch_mangle_17._DenseLayer
  denselayer4 : __torch__.monai.networks.nets.densenet.___torch_mangle_21._DenseLayer
  denselayer5 : __torch__.monai.networks.nets.densenet.___torch_mangle_25._DenseLayer
  denselayer6 : __torch__.monai.networks.nets.densenet.___torch_mangle_29._DenseLayer
  denselayer7 : __torch__.monai.networks.nets.densenet.___torch_mangle_33._DenseLayer
  denselayer8 : __torch__.monai.networks.nets.densenet.___torch_mangle_37._DenseLayer
  denselayer9 : __torch__.monai.networks.nets.densenet.___torch_mangle_41._DenseLayer
  denselayer10 : __torch__.monai.networks.nets.densenet.___torch_mangle_45._DenseLayer
  denselayer11 : __torch__.monai.networks.nets.densenet.___torch_mangle_49._DenseLayer
  denselayer12 : __torch__.monai.networks.nets.densenet.___torch_mangle_53._DenseLayer
  def forward(self: __torch__.monai.networks.nets.densenet.___torch_mangle_54._DenseBlock,
    input: Tensor) -> Tensor:
    _0 = self.denselayer1
    _1 = self.denselayer2
    _2 = self.denselayer3
    _3 = self.denselayer4
    _4 = self.denselayer5
    _5 = self.denselayer6
    _6 = self.denselayer7
    _7 = self.denselayer8
    _8 = self.denselayer9
    _9 = self.denselayer10
    _10 = self.denselayer11
    _11 = self.denselayer12
    input0 = (_0).forward(input, )
    input1 = (_1).forward(input0, )
    input2 = (_2).forward(input1, )
    input3 = (_3).forward(input2, )
    input4 = (_4).forward(input3, )
    input5 = (_5).forward(input4, )
    input6 = (_6).forward(input5, )
    input7 = (_7).forward(input6, )
    input8 = (_8).forward(input7, )
    input9 = (_9).forward(input8, )
    input10 = (_10).forward(input9, )
    return (_11).forward(input10, )
  def __len__(self: __torch__.monai.networks.nets.densenet.___torch_mangle_54._DenseBlock) -> int:
    return 12
